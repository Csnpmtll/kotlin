package com.example.informatics.app

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var textView : TextView ? = null
    private var imageView : ImageView ? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    private fun setInitView(){
        textView=findViewById(R.id.textView)
        imageView=findViewById(R.id.imageView)
        imageView.setBackgroundResource(R.)
    }
    fun addInttoString(value1:Int ,value2:String):String?{
        return "$value1 $value2"
    }
}
